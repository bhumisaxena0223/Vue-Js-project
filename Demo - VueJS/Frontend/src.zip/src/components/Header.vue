<template>
  <div id="main-header">
    <b-navbar toggleable="md" type="light" variant="light" sticky>
      <b-navbar-toggle target="nav_collapse"></b-navbar-toggle>
      <b-navbar-brand href="#" stlye="padding-top: 0rem; padding-bottom: 0rem;">
        <img src="../assets/logo.png" style="height: 44px;" class="d-inline-block align-top" alt="BV">
        <span style="vertical-align: -webkit-baseline-middle;">Demo Work</span>
      </b-navbar-brand>
    </b-navbar>
  </div>
</template>

<script>
export default {
  name: 'MainHeader'
}
</script>

<style scoped>
  #main-header {

  }
</style>
