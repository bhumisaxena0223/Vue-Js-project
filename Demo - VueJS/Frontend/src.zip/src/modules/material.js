const Materials = [
    {
        list: "Commom Carbon Round Steel",
        Api : "CCR Steel"
    },
    {
        list: "Rebar",
        Api : "Rebar"
    },
    {
        list: "Carbon Structural Steel",
        Api : "CS"
    },
    {
        list: "Wire Rod",
        Api : "W Rod"
    },
    {
        list: "Round Bearing Steel",
        Api : "RBS"
    },
    {
        list: "Cold Heading",
        Api : "CHS"
    },
    {
        list: "Color-Coated Steel",
        Api : "C-CS"
    },
    {
        list: "Galvanized Steel",
        Api : "GS"
    },
    {
        list: "HRC hot-rolled coil",
        Api : "HRC"
    } 
]
export default Materials
